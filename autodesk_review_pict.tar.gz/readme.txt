Autodesk Design Review
ProductVersion:   14.0.0.177
FileVersion:      14.0.0.177

dab01b6ded856f0ade4a0bc4f9e1ddc7  SetupDesignReview.exe


(10bc.f80): Access violation - code c0000005 (first chance)
First chance exceptions are reported before any exception handling.
This exception may be expected and handled.
eax=15a3671e ebx=0019dba8 ecx=00001378 edx=00006768 esi=15a353a6 edi=13384000
eip=6ca2df22 esp=0019ba78 ebp=00006768 iopl=0         nv up ei ng nz ac pe cy
cs=0023  ss=002b  ds=002b  es=002b  fs=0053  gs=002b             efl=00010297
MSVCR110!memcpy+0x2a:
6ca2df22 f3a4            rep movs byte ptr es:[edi],byte ptr [esi]
0:000> kv
 # ChildEBP RetAddr  Args to Child              
00 0019ba7c 0cfff52b 1337ec10 15a2ffb6 00006768 MSVCR110!memcpy+0x2a (FPO: [3,0,2])
WARNING: Stack unwind information not available. Following frames may be wrong.
01 0019bac0 0cffd477 0019bafc 0000005b 00000020 ECompositeViewer!DllCanUnloadNow+0xd093b
02 0019bb24 0cffe559 00000002 0019dbec 0019e6e8 ECompositeViewer!DllCanUnloadNow+0xce887
03 00000000 00000000 00000000 00000000 00000000 ECompositeViewer!DllCanUnloadNow+0xcf969
0:000> !exploitable -v
HostMachine\HostUser
Executing Processor Architecture is x86
Debuggee is in User Mode
Debuggee is a live user mode debugging session on the local machine
Event Type: Exception
Exception Faulting Address: 0x13384000
First Chance Exception Type: STATUS_ACCESS_VIOLATION (0xC0000005)
Exception Sub-Type: Write Access Violation

Exception Hash (Major/Minor): 0x724b5244.0x1f4b5244

Stack Trace:
MSVCR110!memcpy+0x2a
ECompositeViewer!DllCanUnloadNow+0xd093b
ECompositeViewer!DllCanUnloadNow+0xce887
ECompositeViewer!DllCanUnloadNow+0xcf969
Instruction Address: 0x000000006ca2df22

Description: User Mode Write AV
Short Description: WriteAV
Exploitability Classification: EXPLOITABLE
Recommended Bug Title: Exploitable - User Mode Write AV starting at MSVCR110!memcpy+0x000000000000002a (Hash=0x724b5244.0x1f4b5244)

User mode write access violations that are not near NULL are exploitable
