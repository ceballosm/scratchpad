javac -cp servlet-api.jar com/sample/mc/Sample.java
zip -r mc.jar atlassian-plugin.xml ./com
