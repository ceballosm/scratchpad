tested against 13.0.0.20259.0

FAILURE_ID_HASH_STRING:  um:software_nx_fault_exploitable_code_c0000005_jt971.dll!jtxtbreponfly::_vftable_

FAILURE_ID_HASH:  {2cc0bb1a-0f7b-f53f-4a73-d594fcb0c0c8}

Followup:     MachineOwner
---------

0:024> !exploitable

!exploitable 1.6.0.0
Exploitability Classification: EXPLOITABLE
Recommended Bug Title: Exploitable - Data Execution Prevention Violation starting at Jt971!JtXTBrepOnFly::`vftable'+0x0000000000152780 (Hash=0xff0fe247.0x4b2c3a2f)

User mode DEP access violations are exploitable.

